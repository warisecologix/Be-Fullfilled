<?php

namespace App\Constant;

class FileConstant
{
    const FLIP_THE_SWITCH_IMAGES = 'images/flip_the_switch';
    const FLIP_THE_SWITCH_MEDIA = 'media/flip_the_switch';

    const CONTENT_LIBRARY_IMAGES = 'images/content_library';
    const CONTENT_LIBRARY_MEDIA = 'media/content_library';

    const  PODCASTS_IMAGES = 'images/podcasts';
    const  PODCASTS_MEDIA = 'media/podcasts';

    const  PRODUCTS_IMAGES = 'images/products';

    const  PUSH_NOTIFICATION_IMAGES = 'images/notification';

    const  ADMIN_IMAGES = 'images/admin';

    const  USER_IMAGES = 'images/user';

    const  BUG_REPORT_MEDIA = 'images/bug_report';

    const STRIPE_API_KEY = 'sk_test_51JK5HMIRuJfsmNeDLYhkvQGtFWh0gcErAxX0rcBzbk0b9QPtsZnaSxIqfBpshGVRqsTUVOUNYsrvBbL75ouLvkFp00KFJLnQJO';
}
