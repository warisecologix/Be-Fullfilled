<?php


namespace App\Constant;


class ProjectConstant
{
    const TOTAL_WEB_PAGINATION = 10;
    const TOTAL_API_PAGINATION = 10;
}
