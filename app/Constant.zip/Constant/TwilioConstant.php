<?php

namespace App\Constant;

class TwilioConstant
{
    const TWILIO_SID = "AC4c649a0a73259c0ac65f312ca1c25aa4";
    const TWILIO_AUTH_TOKEN = "8145e05e17489c40ef9b311f9327ae69";
    const TWILIO_VERIFY_SID = "VA179988c737cf2047f6d6896011f7b4dd";
    const TWILIO_NUMBER = "+18647131451";

}
